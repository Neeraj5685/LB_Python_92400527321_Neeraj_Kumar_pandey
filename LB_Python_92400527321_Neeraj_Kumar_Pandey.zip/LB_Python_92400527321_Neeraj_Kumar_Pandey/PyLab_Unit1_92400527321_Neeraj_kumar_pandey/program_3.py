# Input values
P = float(input("Enter Principal Amount: "))
R = float(input("Enter Rate of Interest: "))
T = float(input("Enter Time (in years): "))

# Calculate SI
SI = (P * R * T) / 100

print("Simple Interest =", SI)