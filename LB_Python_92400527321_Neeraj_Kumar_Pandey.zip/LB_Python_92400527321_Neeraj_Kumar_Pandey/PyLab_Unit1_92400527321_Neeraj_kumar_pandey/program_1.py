# Input two numbers
a = float(input("Enter first number: "))
b = float(input("Enter second number: "))

# Operations
print("Addition =", a + b)
print("Subtraction =", a - b)
print("Multiplication =", a * b)

if b != 0:
    print("Division =", a / b)
else:
    print("Division not possible (cannot divide by 0)")