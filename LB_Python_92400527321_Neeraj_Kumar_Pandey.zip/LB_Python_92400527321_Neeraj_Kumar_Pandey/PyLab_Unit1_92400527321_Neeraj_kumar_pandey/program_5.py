import math

# Input radius
r = float(input("Enter radius: "))

# Calculate area
area = math.pi * r * r

print("Area of circle =", area)