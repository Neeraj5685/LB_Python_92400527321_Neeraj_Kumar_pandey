numbers = input("Enter numbers separated by comma: ")

lst = numbers.split(",")
tpl = tuple(lst)

print("List:", lst)
print("Tuple:", tpl)