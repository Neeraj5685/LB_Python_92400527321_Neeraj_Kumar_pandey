text = input("Enter sentence: ")

words = text.split()
freq = {}

for word in words:
    word = word.capitalize()
    freq[word] = freq.get(word, 0) + 1

for key in sorted(freq):
    print(key, ":", freq[key])