import math

num = int(input("Enter number: "))

print("Square root:", math.sqrt(num))
print("Power:", math.pow(num, 2))
print("Factorial:", math.factorial(num))