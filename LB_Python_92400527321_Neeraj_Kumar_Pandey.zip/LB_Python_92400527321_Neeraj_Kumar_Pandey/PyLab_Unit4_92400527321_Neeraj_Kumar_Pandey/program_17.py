n = int(input("Enter value of n: "))

d = {}
for i in range(1, n+1):
    d[i] = i*i

print("Dictionary:", d)