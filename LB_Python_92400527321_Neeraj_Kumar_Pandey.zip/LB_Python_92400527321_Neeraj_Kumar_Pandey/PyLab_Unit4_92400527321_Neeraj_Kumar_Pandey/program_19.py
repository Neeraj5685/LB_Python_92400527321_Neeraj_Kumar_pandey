def calculate(a, b, op):
    if op == '+':
        print("Result:", a + b)
    elif op == '-':
        print("Result:", a - b)
    elif op == '*':
        print("Result:", a * b)
    elif op == '/':
        print("Result:", a / b)
    else:
        print("Invalid operator")

x = int(input("Enter first number: "))
y = int(input("Enter second number: "))
o = input("Enter operator (+,-,*,/): ")

calculate(x, y, o)