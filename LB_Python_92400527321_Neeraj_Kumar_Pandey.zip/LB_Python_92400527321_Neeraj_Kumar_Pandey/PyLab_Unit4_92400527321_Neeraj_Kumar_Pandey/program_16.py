n = int(input("Enter value of n: "))

lst = []
for i in range(1, n+1):
    lst.append(i*i)

print("List:", lst)