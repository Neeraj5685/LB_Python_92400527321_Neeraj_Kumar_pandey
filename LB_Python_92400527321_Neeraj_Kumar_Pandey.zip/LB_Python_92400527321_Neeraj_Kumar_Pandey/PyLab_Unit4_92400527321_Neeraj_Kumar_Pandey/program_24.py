class Demo:
    def add(self, a=None, b=None, c=None):
        if a != None and b != None and c != None:
            print("Sum:", a + b + c)
        elif a != None and b != None:
            print("Sum:", a + b)
        else:
            print("Invalid input")

obj = Demo()
obj.add(2, 3)
obj.add(2, 3, 4)