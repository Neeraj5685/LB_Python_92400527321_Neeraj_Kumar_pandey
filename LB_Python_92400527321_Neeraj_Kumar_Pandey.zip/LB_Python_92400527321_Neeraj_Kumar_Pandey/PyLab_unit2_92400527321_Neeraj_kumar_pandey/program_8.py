m1 = int(input("Enter marks of subject 1: "))
m2 = int(input("Enter marks of subject 2: "))
m3 = int(input("Enter marks of subject 3: "))
m4 = int(input("Enter marks of subject 4: "))

total = m1 + m2 + m3 + m4
percentage = total / 4

# Check fail condition
if m1 < 40 or m2 < 40 or m3 < 40 or m4 < 40:
    result = "FAIL"
    grade = "With Held**"
else:
    result = "PASS"
    
    if percentage >= 75:
        grade = "Distinction"
    elif percentage >= 60:
        grade = "First Class"
    elif percentage >= 50:
        grade = "Second Class"
    else:
        grade = "Pass Class"

print("Total:", total)
print("Percentage:", percentage)
print("Result:", result)
print("Grade:", grade)