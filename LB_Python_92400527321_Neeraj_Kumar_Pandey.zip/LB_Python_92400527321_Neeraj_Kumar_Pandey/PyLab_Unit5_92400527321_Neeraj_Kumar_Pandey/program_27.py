import matplotlib.pyplot as plt

# Sample Data
labels = ['Python', 'Java', 'C++', 'JavaScript']
sizes = [40, 25, 20, 15]
colors = ['gold', 'lightcoral', 'lightskyblue', 'lightgreen']

plt.figure(figsize=(6, 6))

plt.pie(
    sizes,
    labels=labels,
    colors=colors,
    autopct='%1.1f%%',
    startangle=140,
    explode=(0.1, 0, 0, 0),
    shadow=True
)

plt.title("Pie Chart Example")
plt.axis('equal')  # Equal aspect ratio

plt.show()