import matplotlib.pyplot as plt

# Sample Data
x = [5, 7, 8, 7, 2, 17, 2, 9]
y = [99, 86, 87, 88, 100, 86, 103, 87]
colors = [10, 20, 30, 40, 50, 60, 70, 80]
sizes = [50, 100, 150, 200, 250, 300, 350, 400]

plt.figure(figsize=(8, 5))

plt.scatter(
    x,
    y,
    c=colors,
    s=sizes,
    cmap='viridis',
    alpha=0.7,
    edgecolors='black'
)

plt.title("Scatter Plot Example")
plt.xlabel("X values")
plt.ylabel("Y values")

plt.colorbar()
plt.grid(True)

plt.show()