import matplotlib.pyplot as plt

# Sample Data
data = [12, 15, 14, 10, 18, 20, 22, 19, 17, 13]

plt.figure(figsize=(6, 5))

plt.boxplot(
    data,
    vert=True,
    patch_artist=True,
    boxprops=dict(facecolor='lightblue', color='black'),
    whiskerprops=dict(color='green'),
    capprops=dict(color='red'),
    medianprops=dict(color='blue'),
    flierprops=dict(marker='o', markerfacecolor='red', markersize=6)
)

plt.title("Box Plot Example")
plt.ylabel("Values")

plt.grid(True)

plt.show()