import matplotlib.pyplot as plt

# Sample Data
x = [1, 2, 3, 4, 5]
y = [10, 20, 15, 25, 30]

plt.figure(figsize=(8, 5))

plt.plot(
    x,
    y,
    color='blue',
    linestyle='--',
    linewidth=2,
    marker='o',
    markersize=8,
    markerfacecolor='red',
    markeredgecolor='black',
    label='Sales Data'
)

plt.title("Line Plot Example")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")

plt.legend()
plt.grid(True)

plt.show()