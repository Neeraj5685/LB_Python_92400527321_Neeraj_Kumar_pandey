import matplotlib.pyplot as plt

# Sample Data
categories = ['A', 'B', 'C', 'D']
values = [10, 25, 15, 30]

plt.figure(figsize=(8, 5))

plt.bar(
    categories,
    values,
    color='skyblue',
    edgecolor='black',
    width=0.5,
    align='center',
    alpha=0.8
)

plt.title("Bar Plot Example", fontsize=14)
plt.xlabel("Categories", fontsize=12)
plt.ylabel("Values", fontsize=12)

plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.xticks(rotation=30)

plt.show()